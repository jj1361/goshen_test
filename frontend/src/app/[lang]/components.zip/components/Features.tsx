import Link from 'next/link';
import { getStrapiMedia } from '../utils/api-helpers';
import Image from 'next/image';
import { useQuery } from 'react-query';

interface FeaturesProps {
  data: {
    heading: string;
    description: string;

    feature: Feature[];
  };
}

interface Feature {
  id: string;
  title: string;
  description: string;
  showLink: boolean;
  newTab: boolean;
  url: string;
  text: string;
  media: Media;
}

interface Media {
  data: {
    id: string;
    attributes: {
      url: string;
      name: string;
      alternativeText: string;
    };
  };
}

function Feature({
  title,
  description,
  media,
  showLink,
  newTab,
  url,
  text,
}: Feature) {
  const imgUrl = getStrapiMedia(media.data.attributes.url);
  return (
    <div className='flex flex-col items-center'>
      <h3 className='my-3 text-3xl font-semibold'>{title}</h3>
      <Image
        src={imgUrl || ''}
        alt={media.data.attributes.alternativeText || 'none provided'}
        className='object-contain h-30 sm:h-30 lg:h-50 xl:h-112 2xl:h-128 '
        width={200}
        height={200}
      />
      <div className='space-y-1 leading-tight my-1'>
        <p>{description}</p>
      </div>
      {showLink && url && text && (
        <div>
          <Link
            href={url}
            target={newTab ? '_blank' : '_self'}
            className='inline-block px-4 py-2 mt-4 text-sm font-semibold text-white transition duration-200 ease-in-out bg-violet-500 rounded-lg hover:bg-violet-600'
          >
            {text}
          </Link>
        </div>
      )}
    </div>
  );
}

export default function Features({ data }: FeaturesProps) {
  return (
    <section className='bg-white text-black m:py-12'>
      <div className='container mx-auto space-y-2 text-center '>
        <h2 className='text-5xl font-bold'>{data.heading}</h2>

        <p className='dark:text-gray-400'>{data.description}</p>
      </div>
      <div className='container mx-auto my-6 grid justify-center gap-4 sm:grid-cols-2 lg:grid-cols-4'>
        {data.feature.map((feature: Feature, index: number) => (
          <Feature key={index} {...feature} />
        ))}
      </div>
    </section>
  );
}
