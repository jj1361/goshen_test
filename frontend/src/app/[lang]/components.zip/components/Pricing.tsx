import Image from 'next/image';
import { getStrapiMedia } from '../utils/api-helpers';

interface Feature {
  id: string;
  attributes: {
    name: string;
  };
}

interface Plan {
  id: string;
  name: string;
  description: string;
  price: number;
  pricePeriod: string;
  isRecommended: boolean;
  product_features: {
    data: Feature[];
  };
}

interface PriceProps {
  data: {
    id: string;
    title: string;
    plans: Plan[];
  };
}

export default function Pricing({ data }: PriceProps) {
  // const imgUrl = getStrapiMedia(data.picture.data.attributes.url);
  return (
    <section className='py-20 bg-violet-950 dark:text-gray-100 m:py-12 '>
      <div className='container px-4 mx-auto '>
        <div className='max-w-2xl mx-auto mb-16 text-center'>
          <h2 className='text-4xl font-bold lg:text-5xl'>{data.title}</h2>
        </div>
        <div>
          {/* <Image src='/zoom.png' width={300} height={300} alt='zoom' /> */}
          <p>Catch Us Every 6th Day (Friday) @ 7PM CST & Sabbath @ 11AM CST</p>
        </div>
      </div>
    </section>
  );
}
